import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ ContactServiceTest.class, ContactTest.class })
public class AllTests {

}
