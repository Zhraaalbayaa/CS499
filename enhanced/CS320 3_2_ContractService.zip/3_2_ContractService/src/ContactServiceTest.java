import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit testing of the ContactService repository class. 
 * 
 * @author Zhraa Al Bayaa
 * Date: July 14, 2023
 */
class ContactServiceTest {

	// Id data
	private static String id;
	private static String idTwo;
	private static String idThree;
	
	// First Name
	private static String firstName;
	private static String firstNameTwo;
	private static String firstNameThree; 
		
	// Last Name 
	private static String lastName;
	private static String lastNameTwo;
	private static String lastNameThree;
		
	// Phone
	private static String phone;
	private static String phoneTwo;
	private static String phoneThree;
	
	// Address 
	private static String address;
	private static String addressTwo;
	private static String addressThree;
	
	
	
	@BeforeAll
	public static void setup() {
		
		// Id data
		id = "Id01";
		idTwo = "Id02";
		idThree = "Id03";
		
		// First Name
		firstName = "John";
		firstNameTwo = "Peter";
		firstNameThree = "Johnson"; 
			
		// Last Name 
		lastName = "Doe";
		lastNameTwo = "Shawn";
		lastNameThree = "Lee";
			
		// Phone
		phone = "1231231234";
		phoneTwo = "1112223334";
		phoneThree = "1122334455";
		
		// Address 
		address = "123 Club Rd.";
		addressTwo = "123 7th Ave.";
		addressThree = "123 Church St.";
		
	}
	
	
	
	/**
	 * Test method for {@link ContactService#getService()}.
	 */
	@Test
	void testGetService() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		assertNull(service.getContact(id));
	}

	/**
	 * Test method for {@link ContactService#addContact(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	void testAddContact() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		service.addContact(id, firstName, lastName, phone, address);
		Contact contact = service.getContact(id);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(id, firstNameTwo, lastNameTwo, phoneTwo, addressTwo);
		});
	
		assertEquals("addContact: Contact Id already taken", exception.getMessage());
		service.deleteContact(id);
	}
	
	/**
	 * Test method for {@link ContactService#getContact(java.lang.String)}.
	 */
	@Test
	@DisplayName("Test getContact() Method")
	void testGetContact() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		service.addContact(id, firstName, lastName, phone, address);
		Contact contact = service.getContact(id);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		service.deleteContact(id);
	}

	/**
	 * Test method for {@link ContactService#deleteContact(java.lang.String)}.
	 */
	@Test
	@DisplayName("Test deleteContact() Function")
	void testDeleteContact() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		service.addContact(id, firstName, lastName, phone, address);
		service.addContact(idTwo, firstNameTwo, lastNameTwo, phoneTwo, addressTwo);
		service.addContact(idThree, firstNameThree, lastNameThree, phoneThree, addressThree);
		
		Contact contact = service.getContact(id);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		
		assertTrue(service.deleteContact(id));
		assertNull(service.getContact(id));
		service.deleteContact(idTwo);
		assertNull(service.getContact(idTwo));
		service.deleteContact(idThree);
		assertNull(service.getContact(idThree));
		assertFalse(service.deleteContact(idTwo));
	}

	/**
	 * Test method for {@link ContactService#updateFirstName(java.lang.String, java.lang.String)}.
	 */
	@Test
	@DisplayName("Test updateFirstName() Function")
	void testUpdateFirstName() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		service.addContact(id, firstName, lastName, phone, address);
		
		Contact contact = service.getContact(id);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		
		assertTrue(service.updateFirstName(id, firstNameTwo));
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstNameTwo, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );		
		service.deleteContact(id);
		assertFalse(service.updateFirstName(idTwo, firstName));
	}

	/**
	 * Test method for {@link ContactService#updateLastName(java.lang.String, java.lang.String)}.
	 */
	@Test
	@DisplayName("Test updateLastName() Function")
	void testUpdateLastName() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		service.addContact(id, firstName, lastName, phone, address);
		
		Contact contact = service.getContact(id);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		
		assertTrue(service.updateLastName(id, lastNameTwo));
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastNameTwo, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		service.deleteContact(id);
		assertFalse(service.updateLastName(idTwo, lastName));
	}

	/**
	 * Test method for {@link ContactService#updatePhone(java.lang.String, java.lang.String)}.
	 */
	@Test
	@DisplayName("Test updatePhone() Function")
	void testUpdatePhone() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		service.addContact(id, firstName, lastName, phone, address);
		
		Contact contact = service.getContact(id);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		
		assertTrue(service.updatePhone(id, phoneTwo));
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phoneTwo, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		service.deleteContact(id);
		assertFalse(service.updatePhone(idTwo, phone));
	}

	/**
	 * Test method for {@link ContactService#updateAddress(java.lang.String, java.lang.String)}.
	 */
	@Test
	@DisplayName("Test updateAddress() Function")
	void testUpdateAddress() {
		ContactService service = ContactService.getService();
		assertNotNull(service);
		service.addContact(id, firstName, lastName, phone, address);
		
		Contact contact = service.getContact(id);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(address, contact.getAddress())
	        );
		
		assertTrue(service.updateAddress(id, addressTwo));
		assertAll("Contact",
				() -> assertEquals(id, contact.getContactId()),
	            () -> assertEquals(firstName, contact.getFirstName()),
	            () -> assertEquals(lastName, contact.getLastName()),
	            () -> assertEquals(phone, contact.getPhone()),
	            () -> assertEquals(addressTwo, contact.getAddress())
	        );
		service.deleteContact(id);
		assertFalse(service.updateAddress(idTwo, address));
	}

}
