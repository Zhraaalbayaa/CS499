import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit testing of the Contact class. 
 * 
 * @author Zhraa Al Bayaa
 * Date: July 14, 2023
 */
class ContactTest {

	// Id data
	private String nullId = null; 
	private String emptyId = ""; 
	private String validId = "Id01";
	private String invalidId = "Id1234567890";
	
	// First Name
	private String nullFirstName = null; 
	private String emptyFirstName = ""; 
	private String validFirstName = "John";
	private String validFirstNameTwo = "Peter";	
	private String invalidFirstName = "VeryBigFirstName";
		
	// Last Name 
	private String nullLastName = null; 
	private String emptyLastName = ""; 
	private String validLastName = "Doe";
	private String validLastNameTwo = "Shawn";
	private String invalidLastName = "VeryBigLastName";
		
	// Phone
	private String nullPhone = null; 
	private String emptyPhone = ""; 
	private String validPhone = "1231231234";
	private String validPhoneTwo = "1112223334";
	private String invalidPhone = "111222333444555";
	private String invalidPhoneTwo = "111222333A";
		
	// Address 
	private String nullAddress = null; 
	private String emptyAddress = ""; 
	private String validAddress = "123 Club Rd.";
	private String validAddressTwo = "123 7th Ave.";
	private String invalidAddress = "123 A Very big Address that is not valid";
	

	/**
	 * Test method for {@link Contact#Contact(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	@DisplayName("Parameter Constructor Test for all combinations of parameters")
	void testContactStringStringStringStringString() {
		
		//------ Test Id variations 
		// Test Null Id
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(nullId, validFirstName, validLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Contact ID Parameter", exception.getMessage());
		
		// Test Empty Id
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(emptyId, validFirstName, validLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Contact ID Parameter", exception.getMessage());
		
		// Test Invalid Id
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(invalidId, validFirstName, validLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Contact ID Parameter", exception.getMessage());
		
		
		//------ Test First Name variations 
		// Test Null First Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, nullFirstName, validLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal First Name Parameter", exception.getMessage());
		
		// Test Empty First Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, emptyFirstName, validLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal First Name Parameter", exception.getMessage());
		
		// Test Invalid First Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, invalidFirstName, validLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal First Name Parameter", exception.getMessage());
		
		
		//------ Test Last Name variations 
		// Test Null Last Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, nullLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Last Name Parameter", exception.getMessage());
		
		// Test Empty Last Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, emptyLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Last Name Parameter", exception.getMessage());
		
		// Test Invalid Last Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, invalidLastName, validPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Last Name Parameter", exception.getMessage());
		
		//------ Test Phone variations 
		// Test Null Phone
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, validLastName, nullPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Phone Number Parameter", exception.getMessage());
		
		// Test Empty Phone
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, validLastName, emptyPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Phone Number Parameter", exception.getMessage());
		
		// Test Invalid Phone
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, validLastName, invalidPhone, validAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal Phone Number Parameter", exception.getMessage());
		
		//------ Test address variations 
		// Test Null address
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, validLastName, validPhone, nullAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal address Parameter", exception.getMessage());
		
		// Test Empty address
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, validLastName, validPhone, emptyAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal address Parameter", exception.getMessage());
		
		// Test Invalid address
		exception = assertThrows(IllegalArgumentException.class, () -> {
			new Contact(validId, validFirstName, validLastName, validPhone, invalidAddress);
		});
		
		assertEquals("Constructor ERROR: Illegal address Parameter", exception.getMessage());
		
		// Test Valid data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(validId, contact.getContactId()),
	            () -> assertEquals(validFirstName, contact.getFirstName()),
	            () -> assertEquals(validLastName, contact.getLastName()),
	            () -> assertEquals(validPhone, contact.getPhone()),
	            () -> assertEquals(validAddress, contact.getAddress())
	        );
	}

	/**
	 * Test method for {@link Contact#getContactId()}.
	 */
	@Test
	@DisplayName("Test getContactId() Function")
	void testGetContactId() {
		// Test Valid data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertEquals(validId, contact.getContactId());
	}

	/**
	 * Test method for {@link Contact#getFirstName()}.
	 */
	@Test
	@DisplayName("Test getFirstName() function")
	void testGetFirstName() {
		// Test Valid data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertEquals(validFirstName, contact.getFirstName());
	}

	/**
	 * Test method for {@link Contact#getLastName()}.
	 */
	@Test
	@DisplayName("Test getLastName() Function")
	void testGetLastName() {
		// Test Valid data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertEquals(validLastName, contact.getLastName());
	}

	/**
	 * Test method for {@link Contact#getPhone()}.
	 */
	@Test
	@DisplayName("Text getPhone() Function")
	void testGetPhone() {
		// Test Valid data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertEquals(validPhone, contact.getPhone());
	}

	/**
	 * Test method for {@link Contact#getAddress()}.
	 */
	@Test
	@DisplayName("Text getAddress() Function")
	void testGetAddress() {
		// Test Valid data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertEquals(validAddress, contact.getAddress());
	}

	/**
	 * Test method for {@link Contact#setFirstName(java.lang.String)}.
	 */
	@Test
	@DisplayName("Test setFirstName() Function")
	void testSetFirstName() {
		// Test Valid Id
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(validId, contact.getContactId()),
	            () -> assertEquals(validFirstName, contact.getFirstName()),
	            () -> assertEquals(validLastName, contact.getLastName()),
	            () -> assertEquals(validPhone, contact.getPhone()),
	            () -> assertEquals(validAddress, contact.getAddress())
	        );
		
		//------ Test First Name variations 
		// Test Null First Name
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(nullFirstName);
		});
		
		assertEquals("setFirstName: Invalid First Name Parameter", exception.getMessage());
		
		// Test Empty First Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(emptyFirstName);
		});
		
		assertEquals("setFirstName: Invalid First Name Parameter", exception.getMessage());
		
		// Test Invalid First Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(invalidFirstName);
		});
		
		assertEquals("setFirstName: Invalid First Name Parameter", exception.getMessage());
		
		// Valid First Name update
		contact.setFirstName(validFirstNameTwo);
		assertEquals(validFirstNameTwo, contact.getFirstName());
	}

	/**
	 * Test method for {@link Contact#setLastName(java.lang.String)}.
	 */
	@Test
	@DisplayName("Test setLastName() Function")
	void testSetLastName() {
		// Test valid Data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(validId, contact.getContactId()),
	            () -> assertEquals(validFirstName, contact.getFirstName()),
	            () -> assertEquals(validLastName, contact.getLastName()),
	            () -> assertEquals(validPhone, contact.getPhone()),
	            () -> assertEquals(validAddress, contact.getAddress())
	        );
		
		//------ Test Last Name variations 
		// Test Null Last Name
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(nullLastName);
		});
		
		assertEquals("setLastName: Invalid Last Name Parameter", exception.getMessage());
		
		// Test Empty Last Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(emptyLastName);
		});
		
		assertEquals("setLastName: Invalid Last Name Parameter", exception.getMessage());
		
		// Test Invalid Last Name
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(invalidLastName);
		});
		
		assertEquals("setLastName: Invalid Last Name Parameter", exception.getMessage());
		
		// Valid First Name update
		contact.setLastName(validLastNameTwo);
		assertEquals(validLastNameTwo, contact.getLastName());
	}

	/**
	 * Test method for {@link Contact#setPhone(java.lang.String)}.
	 */
	@Test
	@DisplayName("Test setPhone() Function")
	void testSetPhone() {
		// Test Data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(validId, contact.getContactId()),
	            () -> assertEquals(validFirstName, contact.getFirstName()),
	            () -> assertEquals(validLastName, contact.getLastName()),
	            () -> assertEquals(validPhone, contact.getPhone()),
	            () -> assertEquals(validAddress, contact.getAddress())
	        );
		
		//------ Test Phone variations 
		// Test Null Phone
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone(nullPhone);
		});
		
		assertEquals("setPhone: Invalid Phone Number Parameter", exception.getMessage());
		
		// Test Empty Phone
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone(emptyPhone);
		});
		
		assertEquals("setPhone: Invalid Phone Number Parameter", exception.getMessage());
		
		// Test Invalid Phone
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone(invalidPhone);
		});
		
		assertEquals("setPhone: Invalid Phone Number Parameter", exception.getMessage());
		
		// Test Invalid Phone
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone(invalidPhoneTwo);
		});
		
		assertEquals("setPhone: Invalid Phone Number Parameter", exception.getMessage());
		
		// Valid First Name update
		contact.setPhone(validPhoneTwo);
		assertEquals(validPhoneTwo, contact.getPhone());
	}

	/**
	 * Test method for {@link Contact#setAddress(java.lang.String)}.
	 */
	@Test
	@DisplayName("Test setAddress() Function")
	void testSetAddress() {
		// Test Valid Data
		Contact contact = new Contact(validId, validFirstName, validLastName, validPhone, validAddress);
		assertNotNull(contact);
		assertAll("Contact",
				() -> assertEquals(validId, contact.getContactId()),
	            () -> assertEquals(validFirstName, contact.getFirstName()),
	            () -> assertEquals(validLastName, contact.getLastName()),
	            () -> assertEquals(validPhone, contact.getPhone()),
	            () -> assertEquals(validAddress, contact.getAddress())
	        );
		
		//------ Test Address variations 
		// Test Null Address
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(nullAddress);
		});
		
		assertEquals("setAddress: Invalid Address Parameter", exception.getMessage());
		
		// Test Empty Address
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(emptyAddress);
		});
		
		assertEquals("setAddress: Invalid Address Parameter", exception.getMessage());
		
		// Test Invalid Address
		exception = assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(invalidAddress);
		});
		
		assertEquals("setAddress: Invalid Address Parameter", exception.getMessage());
		
		// Valid Address update
		contact.setAddress(validAddressTwo);
		assertEquals(validAddressTwo, contact.getAddress());
	}
}
