
import java.util.HashMap;

/**
 * Implement the in-memory repository to manage the Contact Objects that will serve as 
 * Contact Service to clients for the contact Management.  
 * 
 * @author Zhraa Al Bayaa
 * Date: July 14, 2023
 *
 */
public class ContactService {
	
	/** Collection of Contacts */
	private HashMap<String, Contact> repository; 
	
	/** Instance of this service object as a singleton service object */
	private static ContactService service; 
	
	/**
	 * Create this Service Instance, cannot be called in public. This 
	 * will enforce using Singleton Design Pattern 
	 */
	private ContactService() {
		this.repository = new HashMap<>();
	}
	
	/**
	 * Provide access to the instance of this class through Singleton Design patter. 
	 * Throughout the life-cycle there will only be single instance of this service.
	 *
	 * @return contactService object
	 */
	public static ContactService getService() {
		
		// Create instance if needed
		if(service == null) {
			service = new ContactService();
		}
		
		return service; 
	}
	
	/**
	 * Get contact for a given id
	 * 
	 * @param id to identify
	 * @return contact object or null
	 */
	public Contact getContact(String id) {
		return repository.get(id);
	}
	
	/**
	 * Add new contact to the ContactService instance using all the fields
	 * for a given Contact. 
	 * 
	 * @param contactId contact id of the Contact
	 * @param firstName first name of the Contact
	 * @param lastName last name of the Contact
	 * @param phone phone number of the Contact
	 * @param address of the Contact
	 * @throws IllegalArgumentException thrown if any parameter is invalid
	 */
	public void addContact(String contactId, String firstName, 
			String lastName, String phone, String address) 
		throws IllegalArgumentException {
		
		// Check if the contact id already exist
		if(this.repository.keySet().contains(contactId)) {
			throw new IllegalArgumentException("addContact: Contact Id already taken");
		}
		
		// Create Contact Object
		Contact contact = new Contact(contactId, firstName, lastName, phone, address);
		
		// store new object into repository
		this.repository.put(contactId, contact);
	}
	
	/**
	 * Delete an existing contact object from the repository
	 * 
	 * @param contactId contact id to remove contact
	 * @return true if the contact has been deleted, return false otherwise
	 */
	public boolean deleteContact(String contactId) {
		return this.repository.remove(contactId) != null;
	}
	
	/**
	 * Update contact based on the contact object. 
	 * 
	 * @param id of contact to update
	 * @param firstName to update
	 * @return true if updated, false otherwise
	 * @throws IllegalArgumentException thrown if parameter is invalid 
	 */
	public boolean updateFirstName(String id, String firstName) 
			throws IllegalArgumentException {
	
		if(repository.containsKey(id)) {
			repository.get(id).setFirstName(firstName);
			return true;
		}
		
		return false; 
	}
	
	/**
	 * Update contact based on the contact object. 
	 * 
	 * @param id of contact to update
	 * @param lastName to update
	 * @return true if updated, false otherwise
	 * @throws IllegalArgumentException thrown if parameter is invalid
	 */
	public boolean updateLastName(String id, String lastName) 
			throws IllegalArgumentException {
		if(repository.containsKey(id)) {
			repository.get(id).setLastName(lastName);
			return true;
		}
		
		return false; 
	}
	
	/**
	 * Update contact based on the contact object. 
	 * 
	 * @param id of contact to update
	 * @param phone to update
	 * @return true if updated, false otherwise
	 * @throws IllegalArgumentException thrown if parameter is invalid
	 */
	public boolean updatePhone(String id, String phone)
			throws IllegalArgumentException {
		
		if(repository.containsKey(id)) {
			repository.get(id).setPhone(phone);
			return true;
		}
		
		return false; 
	}
	
	/**
	 * Update contact based on the contact object. 
	 * 
	 * @param id of contact to update
	 * @param address to update
	 * @return true if updated, false otherwise
	 * @throws IllegalArgumentException thrown if parameter is invalid
	 */
	public boolean updateAddress(String id, String address)
			throws IllegalArgumentException {
		
		if(repository.containsKey(id)) {
			repository.get(id).setAddress(address);
			return true;
		}
		
		return false; 
	}
}
